import "../libs/jquery.js";
import "../libs/jquery.cookie.js";
import { Goods } from "../module/goods.js";

new Goods();